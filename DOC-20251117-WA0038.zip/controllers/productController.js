const Product = require('../models/productModel');

exports.getAllProducts = async (req, res) => {
  try {
    const searchQuery = req.query.q || '';
    // Simple case-insensitive regex search on 'name'
    const filter = searchQuery ? { name: { $regex: searchQuery, $options: 'i' } } : {};
    const products = await Product.find(filter).sort({ createdAt: -1 });
    res.render('products', { products, searchQuery });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
};

exports.getAddForm = (req, res) => {
  res.render('addProduct');
};

exports.createProduct = async (req, res) => {
  try {
    const { name, price, category, description } = req.body;
    await Product.create({ name, price: price ? Number(price) : 0, category, description });
    res.redirect('/products');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error creating product');
  }
};

exports.getEditForm = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).send('Product not found');
    res.render('editProduct', { product });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
};

exports.updateProduct = async (req, res) => {
  try {
    const { name, price, category, description } = req.body;
    await Product.findByIdAndUpdate(req.params.id, { name, price: price ? Number(price) : 0, category, description });
    res.redirect('/products');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error updating product');
  }
};

exports.deleteProduct = async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.redirect('/products');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting product');
  }
};
