# product-crud-app

Simple Product CRUD application using Node.js, Express, MongoDB (Mongoose) and EJS views.
- MVC structure
- CRUD: Create, Read, Update, Delete for Products
- Search by product name with an index on `name`

## Quick Start

1. Install dependencies:
```bash
npm install
```

2. Create `.env` file (you can copy `.env.example`) and set your MongoDB connection string:
```
MONGO_URL=mongodb+srv://<user>:<pass>@cluster0.mongodb.net/myDB?retryWrites=true&w=majority
```

3. Start the server:
```bash
npm start
```

4. Open your browser:
```
http://localhost:3000/products
```

## Notes about Search & Index

The `name` field in the Product schema has an index (`index: true`). To verify the index in MongoDB and check query performance, you can use the following (in the mongo shell or MongoDB Compass query/explain):

Example explain for a simple find by name (regex):
```js
db.products.find({ name: /someName/i }).explain("executionStats")
```

Or to create an index manually (if needed):
```js
db.products.createIndex({ name: 1 })
```

## Project Structure

```
product-crud-app/
┣ controllers/
┣ models/
┣ routes/
┣ views/
┣ app.js
┣ package.json
```

## If you want help to deploy on Replit or GitHub, tell me and I'll guide you step-by-step.
