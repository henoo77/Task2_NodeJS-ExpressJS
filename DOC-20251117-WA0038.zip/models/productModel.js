const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: { type: String, required: true, index: true },
  price: { type: Number, default: 0 },
  category: { type: String, default: '' },
  description: { type: String, default: '' },
  createdAt: { type: Date, default: Date.now }
});

// Ensure index on name (for faster search)
productSchema.index({ name: 1 });

module.exports = mongoose.model('Product', productSchema);
